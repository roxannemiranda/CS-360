package com.example.weightwatchapp

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.ComponentActivity
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.weightwatchapp.ui.theme.WeightWatchAppTheme

class MainActivity : ComponentActivity() {

    lateinit var usernameInput : EditText
    lateinit var passwordInput : EditText
    lateinit var loginBtn : Button
    private lateinit var SignUpbtn: Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)


        usernameInput = findViewById(R.id.username_input)
        passwordInput = findViewById(R.id.password_input)
        loginBtn = findViewById(R.id.login_btn)
        SignUpbtn = findViewById(R.id.SignUpbtn)

        loginBtn.setOnClickListener {
            navigatetoGridlayout()
            val username = usernameInput.text.toString()
            val password = passwordInput.text.toString()
            Log.i("Test Credentials", "Username : $username and Password : $password")
        }

        SignUpbtn.setOnClickListener {
            navitageToRegistration()
        }

    }


       private fun navitageToRegistration() {
            Toast.makeText(this,"Navigating to Registration", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, RegistrationActivity::class.java)
            startActivity(intent)
        }

    private fun navigatetoGridlayout() {
        Toast.makeText(this,"Navigating to Registration", Toast.LENGTH_SHORT).show()
        val intent = Intent(this, GridLayout::class.java)
        startActivity(intent)
    }




                }

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    WeightWatchAppTheme {
        Greeting("Android")
    }
}

class GridLayout : AppCompatActivity() {
    private lateinit var Inputweightbtn: Button
    private lateinit var Trackerbtn: Button
    private lateinit var Optionsbtn: Button
    private lateinit var Logoutbtn: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.gridlayout)

        Inputweightbtn = findViewById(R.id.Inputweight_btn)
        Trackerbtn = findViewById(R.id.Tracker_btn)
        Optionsbtn = findViewById(R.id.Optionsbtn)
        Logoutbtn = findViewById(R.id.Logout_btn)



        Trackerbtn.setOnClickListener {
            navigateToTracker()
        }

        Optionsbtn.setOnClickListener {
            navigateToOptions()
        }

        Logoutbtn.setOnClickListener {
            navigateToMainActivity()
        }

        Inputweightbtn.setOnClickListener {
            navigateToInputweight()
        }

        }



        private fun navigateToTracker() {
            val intent = Intent(this, TrackerActivity::class.java)
            startActivity(intent)

        }

        private fun navigateToOptions() {
            val intent = Intent(this, OptionsActivity::class.java)
            startActivity(intent)

        }

        private fun navigateToMainActivity(){
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

        }

        private fun navigateToInputweight() {
        val intent = Intent(this, WeightInputActivity::class.java)
        startActivity(intent)
        }

        }