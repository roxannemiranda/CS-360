package com.example.weightwatchapp

import android.content.SharedPreferences
import android.widget.CheckBox
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat

class Notifcations : AppCompatActivity() {
    private lateinit var notificationCheckBox: CheckBox

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        setContentView(R.layout.settingslayout)


        notificationCheckBox = findViewById(R.id.notification_checkbox)

        sharedPreferences = getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
        notificationCheckBox.isChecked = sharedPreferences.getBoolean("notifications_enabled", true)


        notificationCheckBox.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("Notifications_enabled", isChecked).apply()
            if (isChecked) {
                sendNotification("Stay on track to reach your goal weight!")
            }
        }
    }

    private fun sendNotification(message: String) {
        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val notificationId = 1
        val intent = Intent(this, Notifcations::class.java)
        val pendingIntent =
            PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)

        val notification = NotificationCompat.Builder(this, "weight_progress_channel")
            .setSmallIcon(R.drawable.bell)
            .setContentTitle("Weight Progress Reminder")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        notificationManager.notify(notificationId, notification.build())
    }
    private fun showOptionsDialog() {

    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel (
            "weight_progress_channel" ,
            "Weight Progress Notification" ,
            NotificationManager.IMPORTANCE_HIGH
            ).apply  {
                description = "Notifications to remind you to stay on track with your weight goals."
            }

            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)


        }
    }

    }

