package com.example.weightwatchapp
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class OptionsActivity:AppCompatActivity() {

    private lateinit var Optionsbtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.gridlayout)

        Optionsbtn = findViewById(R.id.Optionsbtn)

        Optionsbtn.setOnClickListener {
            showOptionsDialog()

        }
    }

    private fun showOptionsDialog() {
        val options = arrayOf("Notification Settings", "About us", "Contact Us")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Options")
        builder.setItems(options) { _, which ->
            when (which) {
                0 -> showNotificationSettings()
                1 -> showAboutUs()
                2 -> showContactUs()

            }
        }

        builder.show()

    }

    private fun showNotificationSettings() {
        Toast.makeText(this, "Navigating to Notfications settings", Toast.LENGTH_SHORT).show()
        val intent = Intent(this, Notifcations::class.java)
        startActivity(intent)
    }

    private fun showAboutUs() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("About Us")
        builder.setMessage("This app was created for educational purposes, CS360, Roxanne Miranda, 2025.")
        builder.setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
        builder.show()

    }

    private fun showContactUs() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Contact Us")
        builder.setMessage(" Concern or Questions? Contact us at Email: roxanne.miranda@snhu. ")
        builder.setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
        builder.show()
    }

}