package com.example.weightwatchapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class RegistrationActivity : AppCompatActivity() {
    private lateinit var name_input: EditText
    private lateinit var Lastname_input: EditText
    private lateinit var username_input: EditText
    private lateinit var password_input: EditText
    private lateinit var login_btn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.registration)

        name_input = findViewById(R.id.name_input)
        Lastname_input = findViewById(R.id.Lastname_input)
        username_input = findViewById(R.id.username_input)
        password_input = findViewById(R.id.password_input)
        login_btn = findViewById(R.id.login_btn)

        login_btn.setOnClickListener {
            registerUser()
        }
    }

    private fun registerUser() {
        val username = username_input.text.toString()
        val password = password_input.text.toString()
        val name = name_input.text.toString()
        val Lastname = Lastname_input.text.toString()


        if (username.isEmpty() || username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show()

        }

        if (name.isEmpty() || name.isEmpty() || Lastname.isEmpty()
        ) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show()

        }
    }

}