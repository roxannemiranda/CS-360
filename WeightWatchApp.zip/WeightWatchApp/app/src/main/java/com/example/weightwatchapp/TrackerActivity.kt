package com.example.weightwatchapp

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.ui.Modifier
import android.widget.ProgressBar
import android.widget.TableRow
import android.widget.TableLayout
import java.io.DataInput


class TrackerActivity : AppCompatActivity() {

    private lateinit var progressBar: ProgressBar
    private lateinit var progressText: TextView
    private lateinit var weightTable: TableLayout
    private lateinit var Weight_input: EditText
    private lateinit var Goalweight_input: EditText



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.trackerlayout)

        progressBar = findViewById(R.id.progress_bar)
        progressText = findViewById(R.id.progress_text)
        weightTable = findViewById(R.id.weight_table)

        val Weight_Input = intent.getStringExtra("WEIGHT")?.toFloatOrNull() ?: 0f

        val Goalweight_Input = intent.getStringExtra("GOAL_WEIGHT")?.toFloatOrNull() ?: 0f



    }

    private fun updateProgressBar(Weight_input: Float, Goalweight_input: Float) {

        if (Goalweight_input > 0) {
            val progress = ((Weight_input / Goalweight_input) * 100).toInt().coerceIn(0, 100)
            progressBar.progress = progress
            progressText.text = "Progress to Goal Weight: $progress%"
        } else {
            progressText.text = "Goal weight must be greated than zero"
        }
    }
}

