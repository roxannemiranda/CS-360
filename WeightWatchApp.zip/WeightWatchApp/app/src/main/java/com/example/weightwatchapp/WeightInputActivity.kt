package com.example.weightwatchapp

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.ui.Modifier


class WeightInputActivity:AppCompatActivity() {

    private lateinit var Weight_input: EditText
    private lateinit var Goalweight_input: EditText
    private lateinit var Trackweigh_btn: Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mainscreen)

        Weight_input = findViewById(R.id.Weight_input)
        Goalweight_input = findViewById(R.id.Goalweight_input)
        Trackweigh_btn = findViewById(R.id.Trackweight_btn)



        Trackweigh_btn.setOnClickListener {
            registerWeight()
        }


    }


    private fun registerWeight() {

        val Weight_Input = Weight_input.text.toString()
        val Goalweight_Input = Goalweight_input.text.toString()

        val intent = Intent(this, TrackerActivity::class.java).apply {
            putExtra("WEIGHT", Weight_Input)
            putExtra("GOAL_WEIGHT", Goalweight_Input)
        }

        startActivity(intent)

        if (Weight_Input.isEmpty() || Goalweight_Input.isEmpty()) {
            Toast.makeText(this, "Please enter both weights", Toast.LENGTH_SHORT).show()
            return
        }


        val currentWeightValue = Weight_Input.toFloatOrNull()
        val goalWeightInputValue = Goalweight_Input.toFloatOrNull()

        if (currentWeightValue == null || goalWeightInputValue == null) {
            Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show()
            return
        }

        Toast.makeText(
            this,
            "Current Weight: $currentWeightValue lb, Goal Weight: $goalWeightInputValue lb",
            Toast.LENGTH_LONG
        ).show()
    }

}